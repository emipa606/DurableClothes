﻿// ReSharper disable UnusedMember.Global
// ReSharper disable UnusedParameter.Global
// ReSharper disable InconsistentNaming

using Harmony;
using HugsLib;
using HugsLib.Settings;
using RimWorld;
using Verse;

namespace DurableClothes
{
    [HarmonyPatch(typeof(Pawn_ApparelTracker))]
    [HarmonyPatch("TakeWearoutDamageForDay")]
    public class DurableClothes_Mod : ModBase
    {
        
        public override string ModIdentifier
        {
            get { return "DurableClothes"; }
        }
        
        private static SettingHandle<bool> toggleFullRepair;
        public override void DefsLoaded() {
            toggleFullRepair = Settings.GetHandle("toggleFullRepair", 
                // TODO translation support
                "Full Repair",
                "When enabled, fully repairs all clothing instead of simply stopping degradation.", 
                true);
        }

        [HarmonyPrefix]
        public static bool PatchMethod_Prefix(ref Thing ap)
        {
            if ((bool) toggleFullRepair) // Only do full repair if the setting is enabled
            {
                ap.HitPoints = ap.MaxHitPoints;
            }
            return false; // don't run the original logic to degrade apparel either way
        }

    }
}
